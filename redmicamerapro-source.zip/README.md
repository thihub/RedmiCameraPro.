# Redmi Camera Pro

Initial Android camera project intended for testing on a Xiaomi Redmi 14C.

## Current implementation
- Rear-camera preview
- Selects the largest JPEG size reported by the camera
- Quality-priority JPEG capture
- Basic automatic/manual exposure and ISO controls where the camera HAL supports them
- Saves captured images to Pictures/RedmiCameraPro

Important: this is an untested initial build. Hardware support varies by device. Contrast/saturation/sharpness sliders are currently UI placeholders and do not modify the saved JPEG. HDR and RAW capture are not implemented yet.

The GitHub Actions workflow builds a debug APK from this project source archive.
