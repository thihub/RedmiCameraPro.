package com.thiago.redmicamerapro;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextureView preview;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private CaptureRequest.Builder previewBuilder;
    private ImageReader imageReader;
    private Handler bg;
    private HandlerThread thread;
    private String cameraId;
    private CameraCharacteristics characteristics;
    private int iso = 0;
    private int exposure = 0;
    private int contrast = 100;
    private int saturation = 100;
    private int sharpness = 0;
    private boolean manual = false;
    private TextView status;
    private SeekBar isoBar;
    private long minExposure = 100000L, maxExposure = 300000000L;
    private int minIso = 100, maxIso = 1600;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 10);
        else startCameraThreadAndOpen();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); return t; }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(16,20,24));
        TextView title = text("REDMI CAMERA PRO", 20); title.setGravity(Gravity.CENTER); title.setPadding(0,dp(14),0,dp(12)); title.setTypeface(null,1); root.addView(title);
        preview = new TextureView(this); root.addView(preview, new LinearLayout.LayoutParams(-1,0,1.0f));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL); controls.setPadding(dp(16),dp(8),dp(16),dp(12)); scroll.addView(controls); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1.0f));
        status = text("Preparando cámara…", 12); status.setTextColor(Color.rgb(128,203,196)); controls.addView(status);
        Button mode = new Button(this); mode.setText("Cambiar a ISO manual / automático"); mode.setOnClickListener(v->{ manual=!manual; updateStatus(); applySettings(); }); controls.addView(mode);
        isoBar = addSlider(controls,"ISO (si el sensor lo permite)",100,3200,iso, val->{iso=val; applySettings();});
        addSlider(controls,"Exposición / obturación (ms aprox.)",1,1000,33,val->{exposure=val; applySettings();});
        addSlider(controls,"Contraste de la foto guardada",50,180,contrast,val->{contrast=val;});
        addSlider(controls,"Saturación de la foto guardada",0,200,saturation,val->{saturation=val;});
        addSlider(controls,"Nitidez de procesamiento",0,100,sharpness,val->{sharpness=val;});
        TextView note = text("Los controles ISO/obturación dependen del soporte del sensor. Contraste, saturación y nitidez se aplican al archivo guardado. Para la máxima calidad, usa buena luz y evita el zoom digital.",12); note.setPadding(0,dp(8),0,dp(8)); controls.addView(note);
        Button capture = new Button(this); capture.setText("●  TOMAR FOTO EN CALIDAD MÁXIMA"); capture.setOnClickListener(v->takePhoto()); controls.addView(capture);
        setContentView(root);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){ if(camera==null && checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) openCamera(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s){return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture s){}
        });
    }
    interface Change { void onChange(int value); }
    private SeekBar addSlider(LinearLayout parent,String label,int min,int max,int initial,Change change){
        TextView l=text(label+": "+initial,13); parent.addView(l); SeekBar b=new SeekBar(this); b.setMax(max-min); b.setProgress(initial-min); parent.addView(b); b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){int val=p+min;l.setText(label+": "+val);if(u)change.onChange(val);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}}); return b;
    }
    private void startCameraThreadAndOpen(){ thread=new HandlerThread("CameraBackground");thread.start();bg=new Handler(thread.getLooper()); if(preview.isAvailable())openCamera(); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startCameraThreadAndOpen();else Toast.makeText(this,"Se necesita permiso de cámara",Toast.LENGTH_LONG).show();}
    private void openCamera(){
        try {
            CameraManager cm=(CameraManager)getSystemService(CAMERA_SERVICE);
            for(String id:cm.getCameraIdList()){CameraCharacteristics c=cm.getCameraCharacteristics(id);Integer facing=c.get(CameraCharacteristics.LENS_FACING);if(facing!=null&&facing==CameraCharacteristics.LENS_FACING_BACK){cameraId=id;characteristics=c;break;}}
            if(cameraId==null){status.setText("No se encontró cámara trasera");return;}
            RangeInfo();
            if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
            cm.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice c){camera=c;startPreview();}public void onDisconnected(CameraDevice c){c.close();camera=null;}public void onError(CameraDevice c,int e){c.close();camera=null;runOnUiThread(()->status.setText("Error al abrir cámara: "+e));}},bg);
        }catch(Exception e){status.setText("No se pudo abrir la cámara: "+e.getMessage());}
    }
    private void RangeInfo(){
        android.util.Range<Integer> r=characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);if(r!=null){minIso=r.getLower();maxIso=Math.min(r.getUpper(),6400);}
        android.util.Range<Long> e=characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);if(e!=null){minExposure=e.getLower();maxExposure=e.getUpper();}
        iso=Math.max(minIso,Math.min(iso==0?minIso:iso,maxIso));
    }
    private void startPreview(){
        try{
            SurfaceTexture st=preview.getSurfaceTexture(); if(st==null)return; st.setDefaultBufferSize(1920,1080);Surface surf=new Surface(st);
            StreamConfigurationMap map=characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);android.util.Size[] sizes=map.getOutputSizes(ImageFormat.JPEG);android.util.Size best=sizes[0];for(android.util.Size s:sizes)if((long)s.getWidth()*s.getHeight()>(long)best.getWidth()*best.getHeight())best=s;
            imageReader=ImageReader.newInstance(best.getWidth(),best.getHeight(),ImageFormat.JPEG,2);
            previewBuilder=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);previewBuilder.addTarget(surf);applyBuilder(previewBuilder);
            camera.createCaptureSession(Arrays.asList(surf,imageReader.getSurface()),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession s){session=s;applySettings();}public void onConfigureFailed(CameraCaptureSession s){runOnUiThread(()->status.setText("No se pudo configurar la cámara"));}},bg);
            runOnUiThread(this::updateStatus);
        }catch(Exception e){runOnUiThread(()->status.setText("Vista previa: "+e.getMessage()));}
    }
    private void applyBuilder(CaptureRequest.Builder b){
        try{
            if(manual){b.set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO);b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_OFF);b.set(CaptureRequest.SENSOR_SENSITIVITY,Math.max(minIso,Math.min(iso,maxIso)));long exp=Math.max(minExposure,Math.min(maxExposure,Math.max(1,exposure)*1000000L));b.set(CaptureRequest.SENSOR_EXPOSURE_TIME,exp);b.set(CaptureRequest.SENSOR_FRAME_DURATION,Math.min(maxExposure,exp+1000000L));}
            else {b.set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO);b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);}
            b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AWB_MODE,CaptureRequest.CONTROL_AWB_MODE_AUTO);
            if(Build.VERSION.SDK_INT>=23){b.set(CaptureRequest.CONTROL_POST_RAW_SENSITIVITY_BOOST,100);}
            b.set(CaptureRequest.JPEG_QUALITY,(byte)100);
        }catch(Exception ignored){}
    }
    private void applySettings(){if(previewBuilder==null||session==null)return;try{applyBuilder(previewBuilder);session.setRepeatingRequest(previewBuilder.build(),null,bg);updateStatus();}catch(Exception e){}}
    private void updateStatus(){if(status==null)return;status.setText("Modo: "+(manual?"MANUAL":"AUTO")+"  |  ISO disponible: "+minIso+"–"+maxIso+"  |  JPEG calidad 100%\nLa cámara puede limitar algunos ajustes.");}
    private void takePhoto(){
        if(camera==null||session==null||imageReader==null){Toast.makeText(this,"La cámara todavía se está iniciando",Toast.LENGTH_SHORT).show();return;}
        try{
            CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(imageReader.getSurface());applyBuilder(b);
            imageReader.setOnImageAvailableListener(reader->{Image img=null;try{img=reader.acquireLatestImage();if(img==null)return;ByteBuffer buf=img.getPlanes()[0].getBuffer();byte[] bytes=new byte[buf.remaining()];buf.get(bytes);saveJpeg(bytes);}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Error guardando: "+e.getMessage(),Toast.LENGTH_LONG).show());}finally{if(img!=null)img.close();}},bg);
            session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){},bg);
        }catch(Exception e){Toast.makeText(this,"No se pudo tomar la foto: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void saveJpeg(byte[] bytes)throws Exception{
        String name="RedmiPro_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";OutputStream out;Uri uri=null;
        if(Build.VERSION.SDK_INT>=29){ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,name);cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");cv.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/RedmiCameraPro");uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);out=getContentResolver().openOutputStream(uri);}else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"RedmiCameraPro");dir.mkdirs();out=new FileOutputStream(new File(dir,name));}
        if(out!=null){out.write(bytes);out.flush();out.close();}runOnUiThread(()->Toast.makeText(this,"Foto guardada en Imágenes/RedmiCameraPro",Toast.LENGTH_LONG).show());
    }
    @Override protected void onPause(){super.onPause();if(camera!=null){camera.close();camera=null;}session=null;}
    @Override protected void onDestroy(){super.onDestroy();if(thread!=null){thread.quitSafely();try{thread.join();}catch(InterruptedException ignored){}thread=null;bg=null;}}
}
